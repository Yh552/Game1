﻿

    public class Character
    {
        private string Charname;
        public String _charname;
        public string race;
        public string classes;
        public int health;
        public int attack;
        public Character( string crace)
        {
            
            race = crace;
            
        }
    public String name
    {
        get { return Charname; } set { Charname = value; } 
    }
        

        public void pickClass()
        {
            string[] prof = { "Warrior", "Archer", "Wizard", };
        notFound:
            Console.WriteLine("Choose one of the classes\n1. warrior\n 2.Archer\n 3.Wizard. \n Please Choose number 1 to 3");
            
            try
            {
                int input = Convert.ToInt32(Console.ReadLine());
                Console.Clear();
                classes = prof[input - 1];
                Console.WriteLine("You picked: " + classes);
                switch (classes)
                {
                    case "Warrior":
                        Console.WriteLine("Warrior uses Greatsword.\nYour health is 13 and your attack power is 9");
                        
                        health = 13;
                        attack = 9;
                        break;
                    case "Archer":
                        Console.WriteLine("Archer uses a Bow\nYour health is 10 and your attack power is 12");
                       
                        health = 10;
                        attack = 12;
                        break;
                    case "Wizard":
                        Console.WriteLine("Wizard uses a Staff\nYour health is 8 and your attack power is 13");
                        health = 8;
                        attack = 13;
                        break;
                    
                        
                        

                }
            }
            catch (IndexOutOfRangeException e)  
            {
                Console.WriteLine("This option is invalid. Choose from the given options");
                
                goto notFound;
            } 

        }

        public void heal()
        {
            Console.WriteLine("You healed for 5 hp");
            
            if (health > 15)
            {
                Console.WriteLine("Your health is full, you cannot have more than 15 hitpoint");
            health = 15;
            }
            else
        {
            health += 5;
        }

        }

        public void fireBall(Monster enemy) 
        {
        enemy.health -= 4;
        Console.WriteLine("You used the special ability fireBall, the enemy hp is  " + enemy.health );
    }

        public void blazeBolt(Monster enemy)
        {
        enemy.health -= 3;
        Console.WriteLine("You used the special ability blazeBolt, the enemy hp is " + enemy.health);
    }

        public void doubleSlash(Monster enemy)
        {
        enemy.health -= 2;
        Console.WriteLine("You used the special ability doubleSlash, the enemy hp is  " + enemy.health);
    }
        public void autoAttack(Monster enemy)
    {
        enemy.health -= 1;
        Console.WriteLine("You have attacked, the enemy hp is  " + enemy.health);
    }

       
    
        public int actionMenu()
        {
            int decision;

        pickAgain:
            Console.WriteLine("Chose you action?");
            Console.WriteLine("1- Attack");
            Console.WriteLine("2- Heal");
            Console.WriteLine("3- Special Ability");

            decision = Convert.ToInt32(Console.ReadLine());
            if (decision > 3 || decision < 0)
            {
                Console.WriteLine("You only have 3 options, please choose again");
                goto pickAgain;
            }


            return decision;
        }

        public void attackType(int decision, Monster enemy,string classes)
        {
            if (decision == 1)
            {
                autoAttack(enemy);
               
            }
            else if (decision == 2)
            {
                heal();
                
            }
            else if (decision == 3)
            {
                                

            switch (classes.ToLower())
            {
                case  "wizard":
                    fireBall(enemy);
                    
                    break;
                case "warrior":
                    doubleSlash(enemy);
                    

                    break;
                default :
                    blazeBolt(enemy);
                    
                    break;
            }
        }
        }
    }
    
