﻿using game1;

class Combat
{
    public static void deadPlayer(Character player)
    {
        if (player.health <= 0)
        {
            Console.WriteLine("YOU DIED!");
            Console.ReadLine();
            Environment.Exit(0);
        }
    }

    public static void goblinFight(Character player, Goblin goblin)
    {
        while (goblin.health > 0 && player.health > 0)
        {

            player.attackType(player.actionMenu(), goblin, player.classes);

            if (goblin.health > 0)
            {
                goblin.monsterRoll(goblin.monsterPicks(), player);
                deadPlayer(player);
            }

        }

        Console.WriteLine(goblin.name + "  was killed");
        Console.ReadLine();
        Console.Clear();
    }
    public static void OrcFight(Character player, Orc orc)
    {
        while (orc.health > 0 && player.health > 0)
        {

            player.attackType(player.actionMenu(), orc, player.classes);

            if (orc.health > 0)
            {
                orc.monsterRoll(orc.monsterPicks(), player);
                deadPlayer(player);
            }

        }

        Console.WriteLine(orc.name + "  was killed");
        Console.ReadLine();
        Console.Clear();
    }
    public static void dragonFight(Character player, Dragon dragon)
    {
        while (dragon.health > 0 && player.health > 0)
        {

            player.attackType(player.actionMenu(), dragon, player.classes);

            if (dragon.health > 0)
            {
                dragon.monsterRoll(dragon.monsterPicks(), player);
                    deadPlayer(player);
            }
            
        }
        Console.WriteLine(dragon.name + "  was killed");
        Console.ReadLine();
        Console.Clear();
    }

}