﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace game1
{
    internal class gamee
    {

        
        

        //constructor
        public gamee()
        {
            Start();

        }

        public void Start()
        {

            //color font to green

            Console.ForegroundColor = ConsoleColor.Green;

            //Title
            Console.WriteLine("Nation Survival");

            Console.WriteLine("Welcome to Nation Survival the game will be located on earth were monsters attacks and you need to defend it!");

            //Character name
            Console.WriteLine("What would you like your character name to be?");


            //Getting the character name
            string Charname = Console.ReadLine();
            Console.WriteLine("Your character name is " + Charname);

            

            //Getting Character race
            Console.WriteLine("There are 3 races to choose from which are Humans, Dwarfs, and elfs");
            string race = Console.ReadLine();
            Console.WriteLine("You chose " + race);

            
            



            Character MyCharacter = new Character( race);
            MyCharacter.name = Charname;
            MyCharacter.pickClass();
            Console.ReadKey();

            //giving the goblin attack damage and health
            Goblin goblin = new Goblin("Goblin", 2, 3);


            Console.WriteLine("You will be fighting a goblin on you next level!\nGet ready!");
            Combat.goblinFight(MyCharacter, goblin);

            //giving the orc attack damage and health
            Orc orc = new Orc("Orc", 3, 5);


            Console.WriteLine("You will be fighting an orc on you next level!\nGet ready!");

            Combat.OrcFight(MyCharacter, orc);

            //giving the dragon attack damage and health
            Dragon dragon = new Dragon("Dragon", 5, 15);


            Console.WriteLine("You will be fighting a dragon on you last level!\nGet ready for the final boss!");

            Combat.dragonFight(MyCharacter, dragon);

            Console.WriteLine(Charname +"Congratz! You have won");

        }



    }
}
