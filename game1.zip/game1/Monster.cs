﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using game1;

public class Monster
{
    public int monsterAttacks, attack, health;
    public string name;

    public Monster(String _name, int _attack, int _health)
    {
        name = _name;
        attack = _attack;
        health = _health;
    }
    public int monsterPicks()
    {

        int mPick;
        Random rand = new Random();
        mPick = rand.Next(1, monsterAttacks + 1);
        return mPick;
    }

    public virtual void monsterRoll(int roll, Character player)
    {
        Console.WriteLine("Monster turn to attack");
    }

}

public class Goblin : Monster
{
    public Goblin(string _name, int _attack, int _health)
        : base(_name, _attack, _health)
    {
        monsterAttacks = 2;

    }
    public void goblinMace(Character player)
    {
        player.health -= 1;
        Console.WriteLine("The Goblin used the goblinMace on you, your remaining health is " + player.health);
        
    }

    public void goblinBite(Character player)
    {
        player.health -= 2;
        Console.WriteLine("The Goblin used the goblinBite on you, your remaining health is " + player.health);
    }

    public override void monsterRoll(int roll, Character player)
    {
        if (roll == 1)
        {
            goblinMace(player);


        }

        else if (roll == 2)
        {
            goblinBite(player);

        }
    }
}
public class Orc : Monster
{
    public Orc(string _name, int _attack, int _health)
        : base(_name, _attack, _health)
    {
        monsterAttacks = 2;

    }
    public void beastHandling(Character player)

    {
        player.health -= 3;
        Console.WriteLine("The Orc used beastHandling on you, your remaining health is " + player.health);

    }

    public void noseBleed(Character player)
    {
        player.health -= 3;
        Console.WriteLine("The Orc used noseBleed on you, your remaining health is " + player.health);

    }

    public override void monsterRoll(int roll, Character player)
    {
        if (roll == 1)
        {
            beastHandling(player);


        }

        else if (roll == 2)
        {
            noseBleed(player);

        }
    }
}
public class Dragon : Monster
{
    public Dragon(string _name, int _attack, int _health)
        : base(_name, _attack, _health)
    {
        monsterAttacks = 2;

    }
    public void fireBreath(Character player)

    {
        player.health -= 5;
        Console.WriteLine("The Dragon used fireBreath on you, your remaining health is " + player.health);

    }

    public void tailCrush(Character player)
    {
        player.health -= 4;
        Console.WriteLine("The Dragon used tailCrush on you, your remaining health is " + player.health);

    }

    public override void monsterRoll(int roll, Character player)
    {
        if (roll == 1)
        {
            fireBreath(player);


        }

        else if (roll == 2)
        {
            tailCrush(player);

        }
    }
}